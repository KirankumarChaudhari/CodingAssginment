﻿using BowlingBall.BowlingGameCalculatorFactory;
using BowlingBall.BowlingGameCalculators;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;

namespace BowlingBall
{
    public static class ServiceConfiguration
    {
        public static IServiceCollection Configure(this IServiceCollection services)
        {
            services.AddScoped<IGame, Game>();
            services.AddScoped<IFrameCalculatorFactory, FrameCalculatorFactory>();

            services.AddTransient<StrikeCalculator>().AddTransient<ICalculator, StrikeCalculator>(s=>s.GetService<StrikeCalculator>());
            services.AddTransient<SpareCalculator>().AddTransient<ICalculator, SpareCalculator>(s => s.GetService<SpareCalculator>());
            services.AddTransient<NormalCalculator>().AddTransient<ICalculator, NormalCalculator>(s => s.GetService<NormalCalculator>());
            return services;
        }
    }
}
