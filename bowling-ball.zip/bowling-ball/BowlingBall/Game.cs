﻿using BowlingBall.BowlingGameCalculatorFactory;
using System;

namespace BowlingBall
{
    public class Game : IGame
    {
        private readonly IFrameCalculatorFactory _frameCalculatorFactory;
        private int[] rolls = new int[21];
        private int currentRoll = 0;

        public Game(IFrameCalculatorFactory frameCalculatorFactory)
        {
            _frameCalculatorFactory = frameCalculatorFactory;
        }
        
        public void Roll(int pins)
        {
           rolls[currentRoll++] = pins;
        }

        public int GetScore()
        {
            // Returns the final score of the game.
            var finalScore = 0;
            var rollIndex = 0;
            
            for (int frame = 0; frame < 10; frame++)
            {
                //Get score for each frame
                var calculator = _frameCalculatorFactory.GetCalculator(rollIndex,rolls);
                var result= calculator.GetFrameScore(rollIndex, rolls);

                finalScore += result.Score;
                rollIndex += result.IncrementIndexBy;
            }

            return finalScore;
        }
    }
}
