﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BowlingBall.Model
{
    public class Result
    {
        public int Score { get; set; }
        public int IncrementIndexBy { get; set; }
    }
}
