﻿using BowlingBall.BowlingGameCalculators;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;

namespace BowlingBall.BowlingGameCalculatorFactory
{
    public class FrameCalculatorFactory : IFrameCalculatorFactory
    {
        private readonly IServiceProvider _serviceProvider;
        public FrameCalculatorFactory(IServiceProvider serviceProvider)
        {
            _serviceProvider = serviceProvider;
        }
        public ICalculator GetCalculator(int rollIndex, int[] rolls)
        {
            ICalculator calculator;
            if (IsStrike(rollIndex, rolls))
            {
                calculator = (ICalculator)_serviceProvider.GetService(typeof(StrikeCalculator));
            }
            else if (IsSpare(rollIndex, rolls))
            {
                calculator = (ICalculator)_serviceProvider.GetService(typeof(SpareCalculator)); 
            }
            else
                calculator = (ICalculator)_serviceProvider.GetService(typeof(NormalCalculator));

            return calculator;  
        }

        private bool IsStrike(int rollIndex,int[] rolls)
        {
            return rolls[rollIndex] == 10;
        }

        private bool IsSpare(int rollIndex, int[] rolls)
        {
            return rolls[rollIndex] + rolls[rollIndex + 1] == 10;
        }
    }
}
