﻿using BowlingBall.BowlingGameCalculators;
using System;
using System.Collections.Generic;
using System.Text;

namespace BowlingBall.BowlingGameCalculatorFactory
{
    public interface IFrameCalculatorFactory
    {
        ICalculator GetCalculator(int rollIndex, int[] rolls);
    }
}
