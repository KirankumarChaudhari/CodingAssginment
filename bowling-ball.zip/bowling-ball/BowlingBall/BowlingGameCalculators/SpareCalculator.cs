﻿using BowlingBall.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace BowlingBall.BowlingGameCalculators
{
    public class SpareCalculator : ICalculator
    {
        public Result GetFrameScore(int rollIndex,int[] rolls)
        {
            var result = new Result() { 
                Score = rolls[rollIndex] + rolls[rollIndex + 1] + rolls[rollIndex + 2] ,
                IncrementIndexBy = 2};
            return result;
        }
    }
}
