﻿using BowlingBall.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace BowlingBall.BowlingGameCalculators
{
    public interface ICalculator
    {
        Result GetFrameScore(int rollIndex,int[] rolls);
    }
}
