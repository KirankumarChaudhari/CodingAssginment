﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BowlingBall
{
    public interface IGame
    {
        void Roll(int pins);
        int GetScore();
    }
}
