using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace BowlingBall.Tests
{
    [TestClass]
    public class GameFixture
    {
        private readonly IGame game;
        public GameFixture()
        {
            IServiceCollection services = new ServiceCollection();
            services.Configure(); //Register services

            var provider = services.BuildServiceProvider();
            game = provider.GetService<IGame>();
        }

        [TestMethod]
        public void Gutter_game_score_should_be_zero_test()
        {
            //Arrange
            Roll(game, 0, 20);

            //Act
            var result = game.GetScore();

            //Assert
            Assert.AreEqual(0, result);
        }

        [TestMethod]
        public void Strike_game_score_should_add_next_2_rolls_test()
        {
            //Arrange
            game.Roll(10);
            game.Roll(5);
            game.Roll(4);

            Roll(game, 0, 16);

            //Act
            var result = game.GetScore();

            //Assert
            Assert.AreEqual(28, result);
        }

        [TestMethod]
        public void Spare_game_score_should_add_next_1_rolls_test()
        {
            //Arrange
            game.Roll(7);
            game.Roll(3);
            game.Roll(5);
           
            Roll(game, 0, 17);

            //Act
            var result = game.GetScore();

            //Assert
            Assert.AreEqual(20, result);
        }

        [TestMethod]
        public void Normal_game_score_should_add_current_rolls_only_test()
        {
            //Arrange
            Roll(game, 1, 20); //All One

            //Act
            var result = game.GetScore();

            //Assert
            Assert.AreEqual(20, result);
        }

        [TestMethod]
        public void Perfect_game_score_should_be_300_test()
        {
            //Arrange
          
            Roll(game, 10, 12);

            //Act
            var result = game.GetScore();

            //Assert
            Assert.AreEqual(300, result);
        }

        [TestMethod]
        public void Random_game_score_should_be_correct_test()
        {
            //Arrange
            game.Roll(10);
            game.Roll(9);
            game.Roll(1);
            game.Roll(5);
            game.Roll(5);
            game.Roll(7);
            game.Roll(2);
            game.Roll(10);
            game.Roll(10);
            game.Roll(10);
            game.Roll(9);
            game.Roll(0);
            game.Roll(8);
            game.Roll(2);
            game.Roll(9);
            game.Roll(1);
            game.Roll(10);

            //Act
            var result = game.GetScore();

            //Assert
            Assert.AreEqual(187, result);
        }

        private void Roll(IGame game, int pins, int times)
        {
            for (int i = 0; i < times; i++)
            {
                game.Roll(pins);
            }
        }
    }
}
